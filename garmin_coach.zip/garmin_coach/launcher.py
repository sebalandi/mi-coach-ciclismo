# launcher.py
"""
Punto de entrada para el ejecutable (.exe) armado con PyInstaller + pywebview.

Arranca el servidor de Streamlit y abre una ventana nativa de Windows apuntando
a esa dirección, sin barra de direcciones ni pinta de navegador.

Esto NO es para correr la app normalmente (para eso: iniciar_app.bat o
`streamlit run app.py`). Es solo el punto de entrada que usa PyInstaller.

--- Por qué está escrito así ---
La primera versión usaba `stcli.main()` y esperaba 3 segundos fijos antes de
abrir la ventana. Empaquetado eso fallaba: la ventana abría y mostraba "no se
puede acceder a esta página" porque el servidor todavía no existía. Tres
cambios lo resuelven:

  1. Se usa `bootstrap.run()` en vez de la línea de comandos de Streamlit. La
     versión de línea de comandos está pensada para una terminal y no arranca
     bien dentro de un ejecutable.
  2. En vez de esperar un tiempo fijo, se consulta el puerto hasta que responde.
     Empaquetado, Streamlit puede tardar 20 o 30 segundos la primera vez -
     bastante más que los 3 segundos que esperaba antes.
  3. Todo queda registrado en un archivo de texto. Como el ejecutable se arma
     sin consola, sin ese registro cualquier falla es invisible.
"""

import os
import socket
import sys
import threading
import time
import traceback
from pathlib import Path

# Marca de versión del lanzador. Queda registrada al arrancar para poder saber,
# mirando el log, si el ejecutable que corrió es el actual o uno viejo sin
# recompilar - que es un enredo fácil de tener: cambiar el código no actualiza
# el .exe hasta que se vuelve a correr construir_exe.bat.
VERSION_LANZADOR = "2026-08-06 · arreglo de developmentMode"

PUERTO = 8765
ESPERA_MAXIMA_SEG = 90

RUTA_LOG = Path.home() / ".mi_coach_ciclismo" / "arranque.log"


def registrar(mensaje):
    """Deja constancia en un archivo, ya que el ejecutable no tiene consola."""
    try:
        RUTA_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(RUTA_LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {mensaje}\n")
    except Exception:
        pass


CARPETA_ACTUALIZADA = Path.home() / ".mi_coach_ciclismo" / "app"
MARCA_FALLO = Path.home() / ".mi_coach_ciclismo" / "arranque_en_curso"


def _version_de(carpeta):
    """Lee el número de versión de un version.py, sin importarlo."""
    ruta = Path(carpeta) / "version.py"
    if not ruta.exists():
        return None
    try:
        return ruta.read_text(encoding="utf-8").split('VERSION = "')[1].split('"')[0]
    except Exception:
        return None


def _como_tupla(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except Exception:
        return (0,)


def ruta_base():
    """
    De dónde cargar el código.

    Si el usuario actualizó la app, los archivos nuevos están en su carpeta
    personal y hay que usarlos en vez de los que vienen dentro del ejecutable —
    es lo que permite actualizar sin reinstalar.

    Con una protección: si el arranque anterior quedó a medias (quedó la marca
    sin borrar), se ignora el código actualizado y se usa el del ejecutable, que
    se sabe que funciona. Así una actualización defectuosa no deja la aplicación
    inutilizable.
    """
    del_ejecutable = sys._MEIPASS if getattr(sys, "frozen", False) \
        else os.path.dirname(os.path.abspath(__file__))

    if not getattr(sys, "frozen", False):
        return del_ejecutable

    if MARCA_FALLO.exists():
        # Antes esto descartaba el código actualizado con solo ver la marca. El
        # problema: si el usuario cierra la app justo después de que el servidor
        # respondió pero antes de que termine de escribir el borrado del archivo
        # (o si el proceso se corta de otra forma no relacionada a un fallo real),
        # la marca queda puesta aunque la actualización haya sido exitosa. El
        # síntoma era el peor posible: la app funcionaba pero nunca usaba el
        # código nuevo, sin ningún error visible.
        #
        # Ahora se mira la ANTIGÜEDAD de la marca. Si tiene menos de 20 segundos,
        # es un arranque legítimo en curso (recién se puso) y no se toca nada. Si
        # es más vieja que eso, quiere decir que quedó de una sesión anterior que
        # sí falló de verdad, y ahí sí se descarta el código actualizado.
        antiguedad = time.time() - MARCA_FALLO.stat().st_mtime
        if antiguedad < 20:
            registrar(f"Marca de arranque reciente ({antiguedad:.0f}s): la ignoro, no es un fallo real.")
        else:
            registrar(f"El arranque anterior falló (marca de {antiguedad:.0f}s): uso el código del ejecutable, no el actualizado.")
            try:
                import shutil
                shutil.rmtree(CARPETA_ACTUALIZADA, ignore_errors=True)
                MARCA_FALLO.unlink(missing_ok=True)
            except Exception:
                pass
            return del_ejecutable

    v_actualizada = _version_de(CARPETA_ACTUALIZADA)
    v_ejecutable = _version_de(del_ejecutable)
    if v_actualizada and v_ejecutable and _como_tupla(v_actualizada) > _como_tupla(v_ejecutable):
        registrar(f"Uso el código actualizado {v_actualizada} (el ejecutable trae {v_ejecutable}).")
        return str(CARPETA_ACTUALIZADA)
    return del_ejecutable


def puerto_responde(puerto):
    """
    True si Streamlit ya está sirviendo contenido de verdad.

    Antes solo comprobaba que el puerto aceptara una conexión TCP, y eso puede
    dar falso positivo: el puerto se abre antes de que la aplicación esté lista
    para responder. Eso hacía que la marca de "arranque en curso" se borrara
    antes de tiempo, o generaba registros confusos donde decía "Servidor listo"
    y recién después "Arrancando Streamlit". Ahora se pide una respuesta HTTP
    real a la página principal.
    """
    try:
        import urllib.request
        with urllib.request.urlopen(f"http://127.0.0.1:{puerto}", timeout=1) as r:
            return r.status == 200
    except Exception:
        return False


def arrancar_streamlit():
    try:
        from streamlit.web import bootstrap

        # Streamlit instala manejadores de señales al arrancar, y Python solo lo
        # permite en el hilo principal. Como acá corre en un hilo secundario (el
        # principal lo necesita la ventana), se anula ese paso. Lo único que se
        # pierde es el apagado ordenado con Ctrl+C, que en una app con ventana no
        # se usa: se cierra cerrando la ventana.
        bootstrap._set_up_signal_handler = lambda *a, **k: None

        from streamlit import config as _config

        base = ruta_base()
        app_path = os.path.abspath(os.path.join(base, "app.py"))
        registrar(f"Arrancando Streamlit desde {app_path}")
        os.chdir(base)

        opciones = {
            # Esta primera opción es imprescindible dentro del ejecutable.
            # Streamlit se considera "en modo desarrollo" cuando su propia ruta
            # no contiene site-packages, y empaquetado sus archivos quedan en
            # _internal\streamlit\, así que se activa solo. En ese modo se niega
            # a aceptar un puerto propio y aborta con un error. Corriendo de la
            # forma normal esto no pasa, que es justo por qué el problema solo
            # aparecía en el .exe.
            "global.developmentMode": False,
            "server.port": PUERTO,
            "server.headless": True,
            "browser.gatherUsageStats": False,
            "theme.base": "light",
            "theme.primaryColor": "#2D4A7C",
            "theme.backgroundColor": "#FBFCFD",
            "theme.secondaryBackgroundColor": "#FFFFFF",
            "theme.textColor": "#131A22",
        }

        # Estos dos pasos previos son los que hace `streamlit run` por dentro.
        # Sin ellos las opciones se ignoran: la primera prueba arrancó en el
        # puerto 8501 en vez del que le pedimos, y la ventana quedaba mirando
        # un puerto vacío.
        _config._main_script_path = app_path
        bootstrap.load_config_options(flag_options=opciones)

        bootstrap.run(app_path, is_hello=False, args=[], flag_options=opciones)
    except Exception:
        registrar("FALLO el arranque de Streamlit:\n" + traceback.format_exc())


def main():
    registrar(f"=== Mi Coach de Ciclismo: iniciando (lanzador {VERSION_LANZADOR}) ===")

    # Marca de arranque en curso: si la app no llega a levantar, la próxima vez
    # se descarta el código actualizado y se usa el del ejecutable.
    try:
        MARCA_FALLO.parent.mkdir(parents=True, exist_ok=True)
        MARCA_FALLO.write_text("1", encoding="utf-8")
    except Exception:
        pass

    hilo = threading.Thread(target=arrancar_streamlit, daemon=True)
    hilo.start()

    # Esperar a que el servidor conteste de verdad, en vez de asumir un tiempo fijo
    inicio = time.time()
    listo = False
    while time.time() - inicio < ESPERA_MAXIMA_SEG:
        if puerto_responde(PUERTO):
            registrar(f"Servidor listo en {time.time() - inicio:.1f} s")
            listo = True
            MARCA_FALLO.unlink(missing_ok=True)   # arrancó bien: se limpia la marca
            break
        time.sleep(0.5)

    if not listo:
        registrar(f"El servidor no respondio en {ESPERA_MAXIMA_SEG} s.")
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0,
                "No pude iniciar la aplicacion.\n\n"
                f"El detalle quedo en:\n{RUTA_LOG}\n\n"
                "Pasale ese archivo a quien te compartio la app.",
                "Mi Coach de Ciclismo",
                0x10,
            )
        except Exception:
            pass
        return

    try:
        import webview
        webview.create_window(
            "Mi Coach de Ciclismo", f"http://localhost:{PUERTO}", width=1300, height=850
        )
        webview.start()
    except Exception:
        # Si la ventana nativa falla, al menos abrimos el navegador
        registrar("La ventana nativa fallo, abro el navegador:\n" + traceback.format_exc())
        import webbrowser
        webbrowser.open(f"http://localhost:{PUERTO}")
        while True:
            time.sleep(3600)


if __name__ == "__main__":
    main()
