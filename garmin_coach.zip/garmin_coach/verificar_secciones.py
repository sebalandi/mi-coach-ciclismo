"""
Comprueba que ninguna sección de la app desaparezca sin explicación, y que no
haya bloques de código duplicados.

Correr con:  python verificar_secciones.py
"""
import re, sys

EXENTAS = {"Gimnasio", "Volumen semanal y riesgo de lesión", "Tiempos que podrías hacer hoy"}
CUBIERTAS_POR = {
    "Curva de potencia · CP y W'": "Potencia",
    "Sesiones con potenciómetro": "Potencia",
}

def main():
    lineas = open("app.py", encoding="utf-8").read().split("\n")
    texto = "\n".join(lineas)
    titulos_con_condicion = {}

    for i, l in enumerate(lineas):
        if not l.strip().startswith("eyebrow("):
            continue
        indent = len(l) - len(l.lstrip())
        condicion = None
        for j in range(i - 1, max(0, i - 12), -1):
            lj = lineas[j]
            if lj.strip().startswith(("if ", "elif ")) and (len(lj) - len(lj.lstrip())) < indent:
                condicion = lj.strip(); break
        m = re.search(r'eyebrow\(\s*"([^"]+)"', l)
        titulo = m.group(1) if m else l.strip()[:40]
        if condicion:
            titulos_con_condicion.setdefault(titulo, []).append(condicion)

    sin_cubrir = []
    for titulo, condiciones in titulos_con_condicion.items():
        if titulo in EXENTAS: continue
        if titulo in CUBIERTAS_POR:
            if f'eyebrow("{CUBIERTAS_POR[titulo]}")' in texto: continue
        apariciones = texto.count(f'eyebrow("{titulo}")')
        tiene_negativa = any(" not " in c for c in condiciones)
        if apariciones < 2 and not tiene_negativa:
            sin_cubrir.append((titulo, condiciones[0]))

    print(f"{'sección':50} estado")
    print("-" * 78)
    for titulo, condiciones in sorted(titulos_con_condicion.items()):
        if titulo in EXENTAS: estado = "exenta"
        elif titulo in CUBIERTAS_POR: estado = f'cubierta por "{CUBIERTAS_POR[titulo]}"'
        elif any(t == titulo for t, _ in sin_cubrir): estado = "SE OCULTA SIN EXPLICAR"
        else: estado = "OK"
        print(f"{titulo[:50]:50} {estado}")

    print()
    print("Secciones que desaparecen sin explicación:", len(sin_cubrir))
    return verificar_duplicados()

def verificar_duplicados():
    lineas = open("app.py", encoding="utf-8").read().split("\n")
    encabezados = [l.strip() for l in lineas if l.startswith("# ---------------- ")]
    repetidos = {e for e in encabezados if encabezados.count(e) > 1}
    print()
    print("Secciones duplicadas:", sorted(repetidos) or "ninguna")
    return 1 if repetidos else 0

if __name__ == "__main__":
    sys.exit(main())
