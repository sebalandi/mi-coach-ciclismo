@echo off
REM Arma el zip para publicar en GitHub, sin datos personales.
REM El trabajo lo hace preparar_publicacion.py: asi los errores se ven en pantalla
REM en vez de cerrar la ventana sin decir nada.

cd /d "%~dp0"
python preparar_publicacion.py

echo.
if errorlevel 1 (
  echo Hubo un problema. Lee el mensaje de arriba antes de subir nada a GitHub.
) else (
  echo Todo en orden.
)
echo.
pause
