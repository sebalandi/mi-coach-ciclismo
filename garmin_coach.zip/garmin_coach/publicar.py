# publicar.py
"""
Publica una nueva version en GitHub con un solo clic.

Hace todo automaticamente:
  1. Verifica que version.py y version.json coincidan
  2. Arma el zip sin datos personales
  3. Sube version.json, version.py y el zip a GitHub

Requiere un token de GitHub con permiso de escritura (solo la primera vez).
Se configura desde la app: panel izquierdo, ACTUALIZACIONES > Configurar publicacion.
O se puede poner directamente en GITHUB_WRITE_TOKEN abajo.
"""

import json
import os
import sys
import zipfile
from pathlib import Path

# Token con permiso de ESCRITURA al repositorio.
# Se genera en GitHub -> Settings -> Developer settings ->
# Personal access tokens -> Fine-grained tokens ->
# Permissions: Contents = Read and write
GITHUB_WRITE_TOKEN = ""

REPO = "sebalandi/mi-coach-ciclismo"   # usuario/repositorio
RAMA = "main"


def token_efectivo(perfil_path):
    token = GITHUB_WRITE_TOKEN.strip()
    if token:
        return token
    try:
        p = json.loads(Path(perfil_path).read_text(encoding="utf-8"))
        return (p.get("github_write_token") or "").strip()
    except Exception:
        return ""


def subir_archivo(gh, repo, ruta_local, ruta_remota, mensaje):
    """Sube o actualiza un archivo en GitHub."""
    contenido = Path(ruta_local).read_bytes()
    try:
        existente = repo.get_contents(ruta_remota, ref=RAMA)
        repo.update_file(ruta_remota, mensaje, contenido, existente.sha, branch=RAMA)
        return "actualizado"
    except Exception:
        repo.create_file(ruta_remota, mensaje, contenido, branch=RAMA)
        return "creado"


def main():
    base = Path(__file__).resolve().parent

    # 1. Verificar versiones
    print("Verificando versiones...")
    try:
        vpy = base.joinpath("version.py").read_text(encoding="utf-8")
        v_py = vpy.split('VERSION = "')[1].split('"')[0]
    except Exception:
        print("  No pude leer version.py")
        return 1
    try:
        d = json.loads(base.joinpath("version.json").read_text(encoding="utf-8"))
        v_json = d.get("version", "")
    except Exception:
        print("  No pude leer version.json")
        return 1

    print(f"  version.py   : {v_py}")
    print(f"  version.json : {v_json}")
    if v_py != v_json:
        print()
        print("  ATENCION: los numeros no coinciden.")
        print("  Corregí uno de los dos antes de publicar.")
        return 1
    print("  Coinciden, bien.")

    # 2. Token
    perfil_path = Path.home() / ".mi_coach_ciclismo" / "datos" / "perfil.json"
    token = token_efectivo(perfil_path)
    if not token:
        print()
        print("FALTA el token de GitHub con permiso de escritura.")
        print("Configuralo en la app: ACTUALIZACIONES > Configurar publicacion.")
        print("O pegalo directamente en GITHUB_WRITE_TOKEN dentro de publicar.py")
        return 1

    # 3. Armar el zip
    print()
    print("Armando el zip...")
    import preparar_publicacion as pp
    url, tok_lectura = pp.config_actualización(base)
    zip_path, _, _ = pp.armar(base, url, tok_lectura)
    r = pp.verificar_zip(zip_path)
    if r["personales"]:
        zip_path.unlink(missing_ok=True)
        print("  ATENCION: el zip iba a contener datos personales. Abortado.")
        return 1
    print(f"  ZIP listo: {r['total']} archivos, sin datos personales.")

    # 4. Subir a GitHub
    print()
    print("Subiendo a GitHub...")
    try:
        from github import Github
    except ImportError:
        print("  Falta la libreria PyGithub.")
        print("  Instalala con:  pip install PyGithub")
        return 1

    try:
        gh = Github(token)
        repo = gh.get_repo(REPO)
        msg = f"v{v_py}: {d.get('notas', 'nueva version')}"

        for archivo, remoto in [
            (base / "version.json", "version.json"),
            (base / "version.py",   "version.py"),
            (zip_path,              "garmin_coach.zip"),
        ]:
            estado = subir_archivo(gh, repo, archivo, remoto, msg)
            print(f"  {remoto}: {estado}")

    except Exception as e:
        print(f"  Error al subir: {e}")
        return 1

    print()
    print("=" * 55)
    print(f"PUBLICADO: version {v_py}")
    print(f"Tus companeros van a ver el aviso la proxima vez que")
    print(f"abran la app.")
    print("=" * 55)
    return 0


if __name__ == "__main__":
    sys.exit(main())
