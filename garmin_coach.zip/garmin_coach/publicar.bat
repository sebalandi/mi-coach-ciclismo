@echo off
REM Publica una nueva version en GitHub con un solo clic.
REM La primera vez instala PyGithub si no esta.

cd /d "%~dp0"

python -c "import github" 2>nul || (
    echo Instalando PyGithub...
    python -m pip install -q PyGithub
)

python publicar.py

echo.
pause
