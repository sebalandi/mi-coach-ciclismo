; instalador.iss
; Script de Inno Setup para empaquetar "Mi Coach de Ciclismo" como un instalador
; de verdad: ícono en el menú de inicio, acceso directo opcional en el escritorio,
; y entrada en "Agregar o quitar programas" para desinstalar prolijamente.
;
; Requiere Inno Setup instalado (gratis): https://jrsoftware.org/isdl.php
; Y haber corrido construir_exe.bat antes (para tener dist\MiCoachDeCiclismo\).
;
; Para compilarlo: construir_instalador.bat (o abrir este archivo con el
; programa de Inno Setup y tocar "Compile").

[Setup]
AppName=Mi Coach de Ciclismo
AppVersion=1.0
AppPublisher=Mi Coach de Ciclismo
DefaultDirName={localappdata}\MiCoachDeCiclismo
DefaultGroupName=Mi Coach de Ciclismo
UninstallDisplayIcon={app}\MiCoachDeCiclismo.exe
Compression=lzma2
SolidCompression=yes
OutputDir=instalador_salida
OutputBaseFilename=Instalador_MiCoachDeCiclismo
; No pide permisos de administrador - se instala en la carpeta del usuario actual,
; para que funcione en PCs de trabajo sin permisos elevados.
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un ícono en el Escritorio"; GroupDescription: "Accesos directos:"

[Files]
Source: "dist\MiCoachDeCiclismo\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Mi Coach de Ciclismo"; Filename: "{app}\MiCoachDeCiclismo.exe"
Name: "{group}\Desinstalar Mi Coach de Ciclismo"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Mi Coach de Ciclismo"; Filename: "{app}\MiCoachDeCiclismo.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\MiCoachDeCiclismo.exe"; Description: "Abrir Mi Coach de Ciclismo ahora"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  CarpetaActualizada: String;
begin
  if CurStep = ssInstall then
  begin
    // Se borra la caché de actualizaciones automáticas ANTES de copiar los
    // archivos nuevos. Por qué: cuando alguien usa "Buscar actualizaciones"
    // desde adentro de la app, el código nuevo se guarda en esta carpeta, y
    // el lanzador la usa en vez del .exe si su número de versión es mayor.
    // Eso está bien para actualizar sin reinstalar - pero si después se
    // instala un .exe nuevo por afuera (este instalador) y su versión no
    // superó a la que ya había quedado cacheada ahí, el lanzador seguía
    // prefiriendo el código viejo cacheado por sobre el ejecutable recién
    // instalado, sin ningún aviso. Instalar una versión nueva tiene que
    // ganarle siempre a lo que haya quedado de una actualización anterior.
    CarpetaActualizada := ExpandConstant('{%USERPROFILE}\.mi_coach_ciclismo\app');
    if DirExists(CarpetaActualizada) then
      DelTree(CarpetaActualizada, True, True, True);
  end;
end;
