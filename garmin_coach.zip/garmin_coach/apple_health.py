# apple_health.py
"""
Importa datos de Apple Salud (VFC y sueño) desde el export nativo de iPhone.

--- Por qué el export nativo y no una app intermedia ---
Se probó primero con Health Auto Export, pero esa app no estaba capturando la
VFC: la columna salía vacía aunque el reloj sí la mide. El export nativo de
Apple Salud (Ajustes de la app Salud → Exportar todos los datos de salud) es
más confiable porque viene directo de la base de datos del teléfono, sin pasar
por ninguna app de terceros. El costo es que el archivo es enorme (el XML de
export puede pesar más de 1 GB), así que este módulo lo procesa por streaming:
lee línea por línea sin cargar el archivo entero en memoria.

--- Qué extrae ---
Variabilidad de la frecuencia cardíaca (HeartRateVariabilitySDNN, la métrica de
Apple que corresponde al SDNN, no al RMSSD que usa Garmin — son escalas
distintas, ver la nota en hrv.py) y análisis de sueño.
"""

import re
import zipfile
from datetime import datetime, date
from pathlib import Path

PATRON_VFC = re.compile(
    rb'<Record type="HKQuantityTypeIdentifierHeartRateVariabilitySDNN"'
    rb'[^>]*startDate="([^"]+)"[^>]*value="([\d.]+)"'
)
PATRON_SUENO = re.compile(
    rb'<Record type="HKCategoryTypeIdentifierSleepAnalysis"'
    rb'[^>]*sourceName="([^"]*)"[^>]*startDate="([^"]+)"[^>]*endDate="([^"]+)"'
    rb'[^>]*value="([^"]+)"'
)

TAMANO_MAXIMO_MB = 3000   # tope de seguridad para no colgar el proceso


def _parsear_fecha_apple(texto):
    """Las fechas de Apple vienen como '2026-08-31 13:27:20 -0300'."""
    try:
        return datetime.strptime(texto[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def _abrir_xml(ruta_o_bytes):
    """
    Devuelve un objeto de archivo en modo binario, aceptando:
      - la ruta a un .xml suelto
      - la ruta a un .zip que lo contenga
      - un objeto tipo archivo/BytesIO ya en memoria, sea el .xml o el .zip

    El último caso es el que usa la app al recibir un archivo subido por el
    usuario: nunca se escribe a disco primero, para no depender de una ruta
    temporal que puede no existir o no tener permisos según el sistema
    operativo (esto rompió en Windows la primera vez, al usar una ruta de
    estilo Linux con /tmp/).
    """
    ruta = Path(ruta_o_bytes) if isinstance(ruta_o_bytes, (str, Path)) else None

    if ruta:
        if ruta.suffix.lower() == ".zip":
            z = zipfile.ZipFile(ruta)
            candidatos = [n for n in z.namelist() if n.lower().endswith(".xml")]
            if not candidatos:
                raise ValueError("El zip no contiene ningún archivo .xml")
            return z.open(candidatos[0])
        return open(ruta, "rb")

    # Objeto en memoria: puede ser el xml directo o un zip que lo contiene.
    # Se detecta mirando los primeros bytes (los zip empiezan con "PK").
    inicio = ruta_o_bytes.read(4)
    ruta_o_bytes.seek(0)
    if inicio[:2] == b"PK":
        z = zipfile.ZipFile(ruta_o_bytes)
        candidatos = [n for n in z.namelist() if n.lower().endswith(".xml")]
        if not candidatos:
            raise ValueError("El zip no contiene ningún archivo .xml")
        return z.open(candidatos[0])
    return ruta_o_bytes


def leer_vfc(ruta_export, desde=None):
    """
    Lee los registros de VFC (SDNN) del export de Apple Salud.

    Procesa el archivo línea por línea — nunca lo carga entero en memoria,
    porque el XML de un historial de años puede pesar varios GB.

    Devuelve una lista de {"fecha_hora": datetime, "sdnn_ms": float}, ordenada
    cronológicamente. `desde` (date) permite ignorar todo lo anterior a esa
    fecha para no procesar años de historial si solo interesa lo reciente.
    """
    resultado = []
    procesados = 0
    with _abrir_xml(ruta_export) as f:
        for linea in f:
            procesados += len(linea)
            if procesados > TAMANO_MAXIMO_MB * 1024 * 1024:
                break
            m = PATRON_VFC.search(linea)
            if not m:
                continue
            fh = _parsear_fecha_apple(m.group(1).decode("utf-8", "ignore"))
            if fh is None:
                continue
            if desde and fh.date() < desde:
                continue
            resultado.append({
                "fecha_hora": fh,
                "sdnn_ms": round(float(m.group(2)), 1),
            })
    resultado.sort(key=lambda r: r["fecha_hora"])
    return resultado


def resumen_diario_vfc(registros):
    """
    Agrupa las lecturas de VFC por día y promedia. Apple toma varias mediciones
    por día (con cada lectura de pulso), a diferencia de Garmin que da un único
    valor nocturno — por eso acá hace falta este paso de resumen.
    """
    por_dia = {}
    for r in registros:
        d = r["fecha_hora"].date()
        por_dia.setdefault(d, []).append(r["sdnn_ms"])

    salida = []
    for d in sorted(por_dia):
        valores = por_dia[d]
        salida.append({
            "fecha": d,
            # Ojo: esto es SDNN, no RMSSD. Apple mide SDNN; Garmin, RMSSD. Son
            # dos formas distintas de calcular la variabilidad del pulso y NO
            # son comparables entre sí en valor absoluto — un SDNN de 40 no
            # equivale a un RMSSD de 40. El campo se llama "rmssd" solo para
            # que encaje con las funciones de hrv.py (línea de base, etc.), que
            # ya están escritas para trabajar sobre EL PROPIO histórico de la
            # persona, sin comparar contra ningún valor de referencia externo.
            # Por eso funcionan igual de bien con SDNN: lo único que les
            # importa es la serie temporal de una métrica consistente consigo
            # misma, no qué métrica sea.
            "rmssd": round(sum(valores) / len(valores), 1),
            "n_lecturas": len(valores),
            "estado": None, "base_min": None, "base_max": None,
            "fuente_metrica": "SDNN (Apple)",
        })
    return salida


def leer_sueno(ruta_export, desde=None):
    """
    Lee el análisis de sueño del export de Apple Salud.

    Devuelve una lista de {"fecha", "inicio", "fin", "horas", "fuente"} por
    cada tramo de sueño registrado (Apple puede grabar varios tramos por noche
    si hubo despertares).
    """
    resultado = []
    procesados = 0
    with _abrir_xml(ruta_export) as f:
        for linea in f:
            procesados += len(linea)
            if procesados > TAMANO_MAXIMO_MB * 1024 * 1024:
                break
            m = PATRON_SUENO.search(linea)
            if not m:
                continue
            fuente, ini_txt, fin_txt, valor = (
                m.group(1).decode("utf-8", "ignore"),
                m.group(2).decode(), m.group(3).decode(),
                m.group(4).decode(),
            )
            if "Asleep" not in valor:   # ignora "InBed" y "Awake" sueltos
                continue
            ini, fin = _parsear_fecha_apple(ini_txt), _parsear_fecha_apple(fin_txt)
            if not ini or not fin:
                continue
            if desde and ini.date() < desde:
                continue
            resultado.append({
                "fecha": ini.date(), "inicio": ini, "fin": fin,
                "horas": round((fin - ini).total_seconds() / 3600, 2),
                "fuente": fuente,
            })
    resultado.sort(key=lambda r: r["inicio"])
    return resultado


def resumen_diario_sueno(registros):
    """Suma los tramos de sueño de cada noche en un total por día."""
    por_dia = {}
    for r in registros:
        por_dia.setdefault(r["fecha"], 0)
        por_dia[r["fecha"]] += r["horas"]
    return [{"fecha": d, "horas": round(h, 2)} for d, h in sorted(por_dia.items())]
