# preparar_publicacion.py
"""
Arma el zip para publicar en GitHub, SIN datos personales.

Genera "garmin_coach.zip" en esta misma carpeta, listo para subir, y verifica que
no lleve nada de la carpeta `data` — donde viven el perfil y la ergoespirometría.
Si esa carpeta llegara a un repositorio público, los datos de salud quedarían a
la vista de cualquiera.

Está escrito en Python y no en el .bat a propósito: la primera versión metía
comandos de PowerShell dentro del .bat y fallaba en silencio, cerrando la ventana
sin decir por qué. En Python se puede probar de verdad y los errores se ven.

Se usa con doble clic en preparar_publicacion.bat, o directamente:
    python preparar_publicacion.py
"""

import json
import os
import sys
import zipfile
from pathlib import Path

# Lo que NO se publica
CARPETAS_EXCLUIDAS = {
    "data",                 # perfil, ergoespirometría y RPE: datos personales
    "__pycache__", ".git", ".idea", ".vscode",
    "build", "dist", "instalador_salida",
}
ARCHIVOS_EXCLUIDOS = {"garmin_coach.zip"}
SUFIJOS_EXCLUIDOS = {".pyc", ".spec"}

NOMBRE_ZIP = "garmin_coach.zip"
RAIZ_EN_ZIP = "garmin_coach"   # el actualizador espera una carpeta raíz


def se_excluye(ruta_relativa):
    partes = ruta_relativa.parts
    if set(partes) & CARPETAS_EXCLUIDAS:
        return True
    if any(p.startswith("_respaldo_") for p in partes):
        return True
    if ruta_relativa.name in ARCHIVOS_EXCLUIDOS:
        return True
    if ruta_relativa.suffix.lower() in SUFIJOS_EXCLUIDOS:
        return True
    return False


def config_actualización(base):
    """
    URL y token que van grabados en el zip publicado.

    Se busca en version.py/actualizador.py primero, y si no hay, en el perfil.
    Así los compañeros reciben el zip ya configurado, sin tocar nada.
    """
    url, token = "", ""

    # Desde version.py
    try:
        texto = (base / "version.py").read_text(encoding="utf-8")
        entre = texto.split("URL_VERSION = ")[1].split("\n")[0]
        url = entre.split('"')[1] if '"' in entre else ""
    except Exception:
        pass

    # Token desde actualizador.py
    try:
        texto = (base / "actualizador.py").read_text(encoding="utf-8")
        entre = texto.split('GITHUB_TOKEN = "')[1].split('"')[0]
        token = entre.strip()
    except Exception:
        pass

    # Si no hay, buscar en el perfil guardado
    if not url or not token:
        try:
            perfil = json.loads((base / "data" / "perfil.json").read_text(encoding="utf-8"))
            if not url:
                url = (perfil.get("url_actualizaciones") or "").strip()
            if not token:
                token = (perfil.get("github_token") or "").strip()
        except Exception:
            pass

    return url, token


def url_configurada(base):
    url, _ = config_actualización(base)
    return (url, "configuración") if url else ("", None)


def grabar_config_en_copia(carpeta_copia, url, token):
    """Graba la URL y el token en los archivos dentro del zip."""
    import re
    cambios = 0

    ruta_v = carpeta_copia / "version.py"
    if ruta_v.exists() and url:
        texto = ruta_v.read_text(encoding="utf-8")
        nuevo = re.sub(r'URL_VERSION = "[^"]*"', f'URL_VERSION = "{url}"', texto, count=1)
        ruta_v.write_text(nuevo, encoding="utf-8")
        if nuevo != texto: cambios += 1

    ruta_a = carpeta_copia / "actualizador.py"
    if ruta_a.exists() and token:
        texto = ruta_a.read_text(encoding="utf-8")
        nuevo = re.sub(r'GITHUB_TOKEN = "[^"]*"', f'GITHUB_TOKEN = "{token}"', texto, count=1)
        ruta_a.write_text(nuevo, encoding="utf-8")
        if nuevo != texto: cambios += 1

    return cambios > 0


def grabar_url_en_copia(carpeta_copia, url):
    return grabar_config_en_copia(carpeta_copia, url, "")


def verificar_versiones(base):
    """Avisa si version.py y version.json no coinciden, que es el error más común."""
    try:
        texto = (base / "version.py").read_text(encoding="utf-8")
        v_py = texto.split('VERSION = "')[1].split('"')[0]
    except Exception:
        v_py = None
    try:
        v_json = json.loads((base / "version.json").read_text(encoding="utf-8")).get("version")
    except Exception:
        v_json = None

    print(f"  version.py   dice: {v_py or 'no pude leerlo'}")
    print(f"  version.json dice: {v_json or 'no pude leerlo'}")
    if v_py and v_json and v_py != v_json:
        print()
        print("  ATENCION: los numeros NO coinciden.")
        print("  El actualizador no va a detectar el cambio hasta que sean iguales.")
        return False
    if v_py and v_json:
        print("  Coinciden, bien.")
    return True


def armar(base, url="", token=""):
    """
    Arma el zip. Se copia todo a una carpeta temporal primero para poder grabar
    ahí la dirección de actualizaciones sin tocar los archivos del proyecto.
    """
    import tempfile, shutil
    salida = base / NOMBRE_ZIP
    if salida.exists():
        salida.unlink()

    tmp = Path(tempfile.mkdtemp(prefix="coach_pub_"))
    copia = tmp / RAIZ_EN_ZIP
    copia.mkdir(parents=True)

    incluidos = []
    for raiz, carpetas, archivos in os.walk(base):
        raiz_p = Path(raiz)
        rel_carpeta = raiz_p.relative_to(base)
        carpetas[:] = [
            c for c in carpetas
            if c not in CARPETAS_EXCLUIDAS and not c.startswith("_respaldo_")
        ]
        if rel_carpeta != Path(".") and se_excluye(rel_carpeta):
            continue
        for a in archivos:
            rel = (rel_carpeta / a) if rel_carpeta != Path(".") else Path(a)
            if se_excluye(rel):
                continue
            destino = copia / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(raiz_p / a, destino)
            incluidos.append(str(rel))

    grabo = grabar_config_en_copia(copia, url, token)

    with zipfile.ZipFile(salida, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz, _, archivos in os.walk(copia):
            for a in archivos:
                p = Path(raiz) / a
                z.write(p, str(Path(RAIZ_EN_ZIP) / p.relative_to(copia)))

    shutil.rmtree(tmp, ignore_errors=True)
    return salida, incluidos, grabo


def verificar_zip(ruta):
    """Confirma que el zip no lleve datos personales y que sirva para actualizar."""
    with zipfile.ZipFile(ruta) as z:
        nombres = z.namelist()

    personales = [
        n for n in nombres
        if "/data/" in n.replace("\\", "/") or n.endswith("perfil.json")
        or n.endswith("rpe_guardados.json")
    ]
    esenciales = ["app.py", "metrics.py", "version.py", "version.json"]
    faltantes = [e for e in esenciales if not any(n.endswith("/" + e) for n in nombres)]

    return {"personales": personales, "faltantes": faltantes, "total": len(nombres)}


def main():
    base = Path(__file__).resolve().parent
    print("Verificando la version...")
    verificar_versiones(base)

    url, token = config_actualización(base)
    print()
    if url:
        print(f"Actualizaciones configuradas:")
        print(f"  URL  : {url}")
        print(f"  Token: {'(configurado)' if token else '(sin token - repo publico)'}")
        print("  Quedan grabados en el zip.")
    else:
        print("ATENCION: no hay URL de actualizaciones configurada.")
        print("  Abrí la app, panel izquierdo, ACTUALIZACIONES > Configurar.")

    print()
    print("Armando el zip sin datos personales...")
    ruta, incluidos, grabo = armar(base, url)

    r = verificar_zip(ruta)
    print()
    print("-" * 60)
    if r["personales"]:
        # Se borra el zip: si queda en la carpeta, tarde o temprano alguien lo sube.
        # Es mejor no tener archivo que tener uno con datos de salud adentro.
        ruta.unlink(missing_ok=True)
        print("ATENCION: el zip iba a contener datos personales.")
        for p in r["personales"]:
            print("   ", p)
        print()
        print("BORRE el zip para que no puedas subirlo por error.")
        print("Avisale a quien te dio la app antes de publicar nada.")
        return 1

    if r["faltantes"]:
        ruta.unlink(missing_ok=True)
        print("El zip quedo incompleto, faltan archivos esenciales:")
        for f in r["faltantes"]:
            print("   ", f)
        print()
        print("Borre el zip. Fijate que no falten archivos en la carpeta del proyecto.")
        return 1

    print(f"LISTO: {NOMBRE_ZIP}  ({r['total']} archivos)")
    print()
    print("  OK: no contiene la carpeta data, ni el perfil, ni los RPE.")
    print("  OK: incluye el codigo completo y la informacion de version.")
    if grabo:
        print("  OK: lleva grabada la direccion de actualizaciones.")
        print("      Tus companeros no tienen que configurar nada.")
    print()
    print("Ahora subilo a GitHub, reemplazando el anterior si ya habia uno.")
    print("-" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
