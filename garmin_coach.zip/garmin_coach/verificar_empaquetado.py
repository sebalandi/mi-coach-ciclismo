"""
Verifica que todos los modulos .py del proyecto (los que importa app.py) esten
incluidos en construir_exe.bat como --add-data y --hidden-import, y que las
librerias de terceros que se importan esten cubiertas con --collect-all.

Existe porque paso dos veces la misma clase de error: se agrego apple_health.py
al proyecto pero se olvido agregarlo al script de empaquetado, y despues se
agrego un `import pydeck` dentro de una funcion (no arriba del archivo) para el
mapa del recorrido, que es mas facil todavia de pasar por alto porque no salta
a la vista al mirar los imports de la cabecera del archivo.

Correr con: python verificar_empaquetado.py
"""
import re
import sys

# Paquetes que ya se sabe que estan bien resueltos sin --collect-all propio
# (vienen como dependencia de otro que si esta cubierto, o son parte de la
# instalacion base de Python).
EXENTOS_DE_COLLECT_ALL = {"go", "px"}  # alias de plotly.graph_objects / plotly.express


def main():
    app = open("app.py", encoding="utf-8").read()
    bat = open("construir_exe.bat", encoding="utf-8").read()

    # --- 1. Modulos propios del proyecto ---
    importados = set(re.findall(r"^import (\w+)$", app, re.MULTILINE))
    propios = {m for m in importados if __import__("os").path.exists(f"{m}.py")}

    en_bat_data = set(re.findall(r'--add-data "(\w+)\.py;', bat))
    en_bat_hidden = set(re.findall(r'--hidden-import (\w+)', bat))

    faltan_data = propios - en_bat_data
    faltan_hidden = propios - en_bat_hidden

    print(f"{'modulo propio':22} en add-data   en hidden-import")
    print("-" * 55)
    for m in sorted(propios):
        print(f"{m:22} {'si' if m in en_bat_data else 'FALTA':10} {'si' if m in en_bat_hidden else 'FALTA'}")

    # --- 2. Librerias de terceros, incluidas las que se importan DENTRO de
    #        una funcion (no solo en la cabecera del archivo) ---
    todos_los_import = set(re.findall(
        r"^\s*import ([\w]+)(?:\.[\w.]+)?(?:\s+as\s+\w+)?\s*$", app, re.MULTILINE
    ))
    stdlib = set(getattr(sys, "stdlib_module_names", ()))
    terceros = todos_los_import - propios - stdlib - EXENTOS_DE_COLLECT_ALL

    en_bat_collect = set(re.findall(r'--collect-all (\w+)', bat))
    faltan_collect = terceros - en_bat_collect

    print()
    print(f"{'libreria de terceros':22} con --collect-all")
    print("-" * 40)
    for m in sorted(terceros):
        print(f"{m:22} {'si' if m in en_bat_collect else 'FALTA'}")

    print()
    problemas = len(faltan_data) + len(faltan_hidden) + len(faltan_collect)
    print("Problemas encontrados:", problemas)
    return 1 if problemas else 0

if __name__ == "__main__":
    sys.exit(main())
