"""
Verifica que todos los modulos .py del proyecto (los que importa app.py) esten
incluidos en construir_exe.bat como --add-data y --hidden-import.

Existe porque paso exactamente esto: se agrego apple_health.py al proyecto pero
se olvido agregarlo al script de empaquetado, y el .exe reconstruido seguia
fallando con ModuleNotFoundError aunque el codigo fuente ya estaba corregido.

Correr con: python verificar_empaquetado.py
"""
import re, sys

def main():
    app = open("app.py", encoding="utf-8").read()
    bat = open("construir_exe.bat", encoding="utf-8").read()

    # Modulos propios que importa app.py (no los de terceros como streamlit)
    importados = set(re.findall(r"^import (\w+)$", app, re.MULTILINE))
    propios = {m for m in importados if __import__("os").path.exists(f"{m}.py")}

    en_bat_data = set(re.findall(r'--add-data "(\w+)\.py;', bat))
    en_bat_hidden = set(re.findall(r'--hidden-import (\w+)', bat))

    faltan_data = propios - en_bat_data
    faltan_hidden = propios - en_bat_hidden

    print(f"{'modulo':22} en add-data   en hidden-import")
    print("-" * 55)
    for m in sorted(propios):
        print(f"{m:22} {'si' if m in en_bat_data else 'FALTA':10} {'si' if m in en_bat_hidden else 'FALTA'}")

    print()
    problemas = len(faltan_data) + len(faltan_hidden)
    print("Problemas encontrados:", problemas)
    return 1 if problemas else 0

if __name__ == "__main__":
    sys.exit(main())
