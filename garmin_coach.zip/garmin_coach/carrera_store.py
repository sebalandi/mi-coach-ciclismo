# carrera_store.py
"""
Guarda qué sesiones fueron competencias, en un archivo local.

Garmin sabe esto solo si la actividad se editó como "Carrera" en Garmin
Connect (queda en el campo eventType). Para todo lo demás -actividades
importadas de un archivo, o carreras que nunca se marcaron en Garmin- hace
falta que la persona lo indique a mano. Se guarda acá, igual que el RPE, en
vez de en el perfil, para no mezclar datos de identidad con marcas de sesión.

Un valor explícito acá (True o False) siempre pisa lo que haya detectado
Garmin: así, si Garmin la marcó mal, se puede corregir.
"""

import json
import os

import config

RUTA_ARCHIVO = os.path.join(config.RUTA_DATOS, "carreras_marcadas.json")


def _asegurar_carpeta():
    os.makedirs(config.RUTA_DATOS, exist_ok=True)


def cargar_todos():
    if not os.path.exists(RUTA_ARCHIVO):
        return {}
    try:
        with open(RUTA_ARCHIVO, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def obtener(activity_id):
    """True/False si hay una marca manual, o None si no se tocó nada."""
    return cargar_todos().get(str(activity_id))


def marcar(activity_id, valor):
    _asegurar_carpeta()
    datos = cargar_todos()
    datos[str(activity_id)] = bool(valor)
    with open(RUTA_ARCHIVO, "w", encoding="utf-8") as f:
        json.dump(datos, f)


def es_competencia(sesion):
    """
    Si esta sesión cuenta como competencia: la marca manual, si existe, tiene
    prioridad sobre lo que haya detectado Garmin automáticamente.
    """
    manual = obtener(sesion.get("id"))
    if manual is not None:
        return manual
    return bool(sesion.get("es_competencia_garmin"))


def borrar():
    """Elimina todas las marcas guardadas."""
    if os.path.exists(RUTA_ARCHIVO):
        os.remove(RUTA_ARCHIVO)
